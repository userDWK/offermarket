import React from "react";
import SellResistPage from "../../sell/SellResistPage";

const ModifySell = () => {
  return <SellResistPage />;
};

export default ModifySell;
